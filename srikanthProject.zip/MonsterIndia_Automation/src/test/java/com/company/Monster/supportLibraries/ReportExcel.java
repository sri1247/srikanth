package com.company.Monster.supportLibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
import java.sql.Driver;

//import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.util.HSSFColor;
//import org.apache.poi.ss.usermodel.CreationHelper;
//import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
//import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.openqa.selenium.TakesScreenshot;



public class ReportExcel{
	public static XSSFCellStyle cellStyl;
	public XSSFCell cell; 
	public static XSSFWorkbook wb;
	public static String Report = testVariables.fileOutput;
	public static int rowCount = 0;

	public static void createReport () 
	{ 
		try 
		{ 

			wb = new XSSFWorkbook(); 

			cellStyl = wb.createCellStyle();			

			cellStyl.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND );
			cellStyl.setFillForegroundColor(new HSSFColor.PALE_BLUE().getIndex());
			cellStyl.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
			cellStyl.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
			cellStyl.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
			cellStyl.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);

			XSSFSheet xs = wb.createSheet("Output"); 
			//Creating a row 
			XSSFRow xr = xs.createRow(0); 
			//Creating a columns/headers 
			XSSFCell cell = xr.createCell(0);
			cell.setCellValue("Test Case #"); 
			cell.setCellStyle(cellStyl);
			cell = xr.createCell(1);
			cell.setCellValue("Test Summary"); 
			cell.setCellStyle(cellStyl);
			cell = xr.createCell(2);
			cell.setCellValue("Expected Result");
			cell.setCellStyle(cellStyl);
			cell = xr.createCell(3);
			cell.setCellValue("Actual Results"); 
			cell.setCellStyle(cellStyl);

			cell = xr.createCell(4);
			cell.setCellValue("Status"); 
			cell.setCellStyle(cellStyl);

			//Moving the file from Virtual ram to physical ram 
			FileOutputStream fo = new FileOutputStream(new File(Report)); 
			wb.write(fo); fo.close(); 
		} 
		catch (IOException e1) 
		{ // TODO Auto-generated catch block 
			System.out.println("createReport File not found..IO Exception"); 
		} 
		catch (Exception e) 
		{ // TODO Auto-generated catch block 
			System.out.println(e.getMessage()); 
			System.out.println("Unknown exception"); 

		} 
	}

	@SuppressWarnings("resource")
	public static void addstep(String testSummary,String expectedResult, String actualResult, String status) 
	{ 
		//String expectedResult;
		try 
		{
			FileInputStream is = new FileInputStream(new File(Report)); 
			XSSFWorkbook wb = new XSSFWorkbook(is); 

			XSSFCellStyle cS = wb.createCellStyle();
			XSSFCellStyle cSReport = wb.createCellStyle();
			cS.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
			cS.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
			cS.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
			cS.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);			
			cSReport.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND );
			if(status.toUpperCase().equals("PASS")){cS.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
			cS.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
			cS.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
			cS.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);
				
				cSReport.setFillForegroundColor(new HSSFColor.GREEN().getIndex());
			}
			else if(status.toUpperCase().equals("FAIL"))
			{
				//ScreenShotLib.takeScreenshotAndSave(testcaseValidated);
				cSReport.setFillForegroundColor(new HSSFColor.RED().getIndex());
			}
			else if(status.toUpperCase().equals("WARN"))
			{
				cSReport.setFillForegroundColor(new HSSFColor.YELLOW().getIndex());
			}
			else if(status.toUpperCase().equals("DONE"))
				cSReport.setFillForegroundColor(new HSSFColor.LEMON_CHIFFON().getIndex());


			XSSFSheet sheet = wb.getSheet("Output"); 
			rowCount = sheet.getLastRowNum(); 
			System.out.println("# of rows in output sheet: "+rowCount);
			System.out.println("--------------------------------------- ");

			XSSFRow rw= sheet.createRow(rowCount+1); 
			XSSFCell cell = rw.createCell(0);
			cell.setCellValue(rowCount+1); //Testcase #
			cell.setCellStyle(cS);
			cell = rw.createCell(1);
			cell.setCellValue(testSummary);//Test Summary Cell 
			cell.setCellStyle(cS);
			cell = rw.createCell(2); 
			cell.setCellValue(expectedResult); //Expected Result Cell 
			cell.setCellStyle(cS);
			cell = rw.createCell(3);
			cell.setCellValue(actualResult);//Actual Result Cell
			cell.setCellStyle(cS);
			cell = rw.createCell(4);
			cell.setCellValue(status);//status Cell
			cell.setCellStyle(cS);
			cell.setCellStyle(cSReport);
			FileOutputStream fo = new FileOutputStream(new File(Report)); 
			wb.write(fo); 
			fo.close(); 
		} 
		catch (IOException e1) 
		{ // TODO Auto-generated catch block 
			System.out.println("addStep File not found..IO Exception for:"+testSummary); 
		} 
		catch (Exception e) 
		{ // TODO Auto-generated catch block 
			System.out.println("addStep Unknown exception for:"+testSummary);  
			System.out.println(e.getMessage()); 
			e.printStackTrace();
		}
	}

}

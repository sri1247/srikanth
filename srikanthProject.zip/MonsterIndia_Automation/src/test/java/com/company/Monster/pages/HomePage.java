package com.company.Monster.pages;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
//import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.poi.ddf.EscherColorRef.SysIndexProcedure;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.company.Monster.factory.PageFactory;
import com.company.Monster.objectRepository.*;
import com.company.Monster.supportLibraries.*;


public class HomePage extends PageBase{
	public static String strDashBoard;
	public static String strReport;
	//public OBIEELib obieeLib;
	public HomePage(RemoteWebDriver driver, PageFactory pageFactory){
		super(driver, pageFactory);
		//obieeLib = new OBIEELib();
	}


	public HomePage closingChildWindow() {
		
		String winHandleBefore = driver.getWindowHandle();
		
		//Switch to new window opened
		for (String winHandle : driver.getWindowHandles()) {
		    driver.switchTo().window(winHandle);
		}

		// Perform the actions on new window
		driver.close(); //this will close new opened window

		//switch back to main window using this code
		driver.switchTo().window(winHandleBefore);

		return this;
		
    }

	public HomePage handleAlert(String strAction) throws Exception
	{
		invokeWebDriverWait(150, "alertispresent", "", "");
		Alert alert=driver.switchTo().alert();
		if(strAction.toLowerCase().equals("accept"))
			alert.accept();
		else if(strAction.toLowerCase().equals("dismiss"))
			alert.dismiss();

		return this;

	}

	/*public HomePage waitForPageLoad() throws Exception

	{
		waitForPgLoad();

		return this;

	}*/
	
	public HomePage closingConfirmDetailsPopup() throws Exception

	{
		clickOnEle("xpath", ".//div[contains(@class,'rpop_close')]");

		System.out.println("closing the confirmation window");

		return this;

	}

	public MPowerSearchPage clickOnmPower() throws Exception

	{
		
		Thread.sleep(5000);
		
		clickOnEle("xpath", ".//li[@id='mpower']");		

		System.out.println("clicked on mPower");

		return new PageFactory(driver).mpowersearchPage();

	}
	
}


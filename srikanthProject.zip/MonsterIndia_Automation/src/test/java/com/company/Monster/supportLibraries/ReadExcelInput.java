package com.company.Monster.supportLibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelInput{

	static String fileInput;


	@SuppressWarnings("resource")
	public static String readFromCell(String header) throws IOException 
	{ 
		String val = "";
		//System.out.println(header);
		try 
		{ 

			fileInput = testVariables.fileInput; 
			System.out.println("Input file: "+fileInput);
			int headCell = 0; 
			FileInputStream fis=new FileInputStream(new File(fileInput)); 
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet;
			if(header.equals("Url")||header.equals("Browser")||header.equals("Any")||header.equals("All")||header.equals("Excluding")||header.equals("CriteriaType")||header.equals("ExcludeSynonyms")||header.equals("MinYrs")||header.equals("MaxYrs")||header.equals("Industry")||header.equals("TopSearchRole")||header.equals("ChooseFromAllRoles")||header.equals("SubTopSearchRole")||header.equals("SubChooseFromAllRoles")){

				sheet = wb.getSheet("MonsterIndiaInputData");

			}
			
			else if(header.equals("ApplicationNameinPlanningSystemView")||header.equals("CubeNameinPlanningSystemView")||header.equals("ApplicationNameinEssbaseSystemView")||header.equals("CubeNameinEssbaseSystemView")){

				sheet = wb.getSheet("NaukriInputData");

			}
			
			
			else {

				sheet = wb.getSheet("input"); 

			}

			XSSFRow headRw = sheet.getRow(0); 
			int intCols = headRw.getLastCellNum(); 
			for(int i=0;i<intCols;i++) 
			{ 
				if(headRw.getCell(i).getStringCellValue().equalsIgnoreCase(header)) 
				{ 
					headCell = i; 
					break; 
				} 
			} 
			//System.out.println("head cell: "+headCell);
			int inttotRw = sheet.getLastRowNum(); 
			int intTestRw =0 ; 

			for(int i=1;i<=inttotRw;i++) 
			{ 
				if(sheet.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(testVariables.executeClassName)); 
				{
					intTestRw = i;
					break;
				} 
			} 
			//System.out.println("intTestRw cell: "+intTestRw);
				
			val = sheet.getRow(intTestRw).getCell(headCell).getStringCellValue();
			
		} 

		catch (IOException e1) 
		{ // TODO Auto-generated catch block 
			System.out.println("File not found..IO Exception"+fileInput); 
		} 
		catch (Exception e) 
		{
			System.out.println("Either the cell is null or some unknown error occured in Reading the input file"); 
			System.out.println(e.getMessage()); 
			
			e.printStackTrace();
		} 
		return val; 
	} 
}

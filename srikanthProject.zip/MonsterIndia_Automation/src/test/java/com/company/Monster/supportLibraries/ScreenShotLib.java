package com.company.Monster.supportLibraries;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.company.Monster.objectRepository.*;
import com.company.Monster.pages.*;
import com.company.Monster.supportLibraries.*;

public class ScreenShotLib extends PageBase {

	static RemoteWebDriver driver = null;
	public ScreenShotLib(RemoteWebDriver driver) {
		//System.out.println("screenslibn: "+driver.getTitle());
		this.driver = driver;
	}
	
	public static String takeScreenshotAndSave(String testcaseName)
	{
		String screenshotName = "";
		try
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			String date = dateFormat.format(cal.getTime());
			String snapTime = date.toString();
			snapTime = snapTime.replaceAll(" ", "");
			snapTime = snapTime.replaceAll(":", "");
			snapTime = snapTime.replaceAll("/", "");
			//System.out.println("In takeScreenshotAndSave: "+testcaseName);
			//System.out.println("the title is :"+driver.getTitle());
			File screenShotSrcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			//System.out.println("just afer line");
			screenshotName = testVariables.screenShotPath+"\\"+testVariables.currentTestCase+"_"+CommonLibrary.getDate()+"_"+snapTime+".png";
			//System.out.println("the variable :"+screenshotName);
			//screenshotName = screenshotName.replaceAll("\\", "/");
			//System.out.println("the variable :"+screenshotName);
			FileUtils.copyFile(screenShotSrcFile, new File(screenshotName));
			//System.out.println("just afer copy line");
		}
		catch(Exception e)
		{
			System.out.println("the exception is :"+e.getMessage());
			//ReportExcel.addstep("Unable to take screenshot", "Fail");
		}
		return screenshotName;
	}
	
}

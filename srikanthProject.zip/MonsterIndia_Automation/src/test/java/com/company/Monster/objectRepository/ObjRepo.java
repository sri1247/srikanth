package com.company.Monster.objectRepository;

public class ObjRepo {



//login
	public static final String LoginPage_UserName_name="login";
	public static final String LoginPage_Password_CSS="input[id*='txtPassword']";
	public static final String LoginPage_SignOn_CSS="button[id*='btnLogon']";


	//homepage

	public static final String HomePage_ConfirmationDEtailsPopupClose_xpath=".//div[contains(@class,'rpop_close')]";	
	
	
	//Navigate Components
	public static final String HomePage_Navigate_xpath=".//span[text()='N']";
	public static final String HomePage_Application_xpath=".//td[text()='A']";
	public static final String HomePage_Planning_xpath=".//td[text()='Planning']";
	public static final String HomePage_BodySPace_xpath=".//*[@class='bi-component secondaryLayerHidden']";
	public static final String HomePage_Administer_xpath=".//span[text()='A']";
	public static final String HomePage_CalcManager_xpath=".//td[contains(text(),'Calcula')]";
	public static final String HomePage_CalcManagerSystemView_xpath=".//table[@summary='System View']";
	public static final String HomePage_ClosingApplciation_xpath=".//img[@alt='Close']";
	public static final String HomePage_SharedServices_xpath=".//td[contains(text(),'hared Services Console')]";
	public static final String HomePage_SharedServicesApplicationManagement_xpath=".//table[@class='bi-tree-view-table']";



	//Preferences Components

	public static final String HomePage_File_xpath=".//span[contains(text(),'ile')]";
	public static final String HomePage_Preferences_xpath=".//td[contains(text(),'Pre')]";
	public static final String HomePage_GeneralPreferences_xpath=".//button[text()='General']";
	public static final String HomePage_GeneralContent_xpath=".//div[@class='bi-label combo-box-label']";
	public static final String HomePage_PlanningPreferences_xpath=".//button[text()='Planning']";
	public static final String HomePage_PlanningPrompt_xpath="html/body/table/tbody/tr/td";
	//	public static final String HomePage_ClosingApplciation_xpath=".//img[@alt='Close']";
	public static final String HomePage_OKInPreferences_xpath=".//button[@class='bi-button buttonPrimary']";



	//Calculation Manager Planning and Essbase Options	

	public static final String HomePage_SelectView_xpath=".//div[@title='Select View']";
	public static final String HomePage_View_xpath=".//div[@title='View']";
	public static final String HomePage_Actions_xpath=".//a[text()='ctions']";	
	public static final String HomePage_PlanningNameExpand_xpath="//img[@alt='Planning']/../span";
	public static final String HomePage_EssbaseNameExpand_xpath="//img[@alt='Essbase']/../span";

	public static final String HomePage_CubeTableAndRuleFilesTableInEssBase_xpath=".//*[@id='pt1:pt_region0:1:pc1:tt1::db']/table[3]/tbody";
	public static final String HomePage_CubeTableInPlanning_xpath=".//*[@id='pt1:pt_region0:1:pc1:tt1::db']/table[3]/tbody";
	public static final String HomePage_RuleFilesInPlanning_xpath=".//*[@id='pt1:pt_region0:1:pc1:tt1::db']/table[5]/tbody";
	public static final String HomePage_Rules_xpath="//img[@alt='Rules']/../span";



	////Workspace Settings	

	public static final String HomePage_WorkSpaceSettings_xpath=".//td[text()='kspace Settings']";
	public static final String HomePage_ServerSettings_xpath=".//td[text()='ver Settings']";
	public static final String HomePage_WorkSpaceServerSettingsWindowHeader_xpath=".//div[text()='Workspace Server Settings']";	
	public static final String HomePage_SupportedLocales_xpath="//div[text()='Supported Locales:']/following::div";
	public static final String HomePage_DefaultLocale_xpath="//div[text()='Default Locale:']/following::div";
	public static final String HomePage_clientDebug_xpath="//div[text()='Client Debug Enabled:']/following::div";
	public static final String HomePage_SessionTimeOut_xpath="//div[text()='Session Timeout (minutes):']/following::div";
	public static final String HomePage_KeepAliveInterval_xpath="//div[text()='Keep-Alive Interval (minutes):']/following::div";
	public static final String HomePage_RequiredLogon_xpath="//div[text()='Required Logon Role:']/following::div";
	public static final String HomePage_EnableNativeUserPasswordChange_xpath="//div[text()='Enable Native User Password Change:']/following::div";
	public static final String HomePage_HTTPRequestURL_xpath="//div[text()='Accept Credentials in a HTTP Request URL:']/following::div";
	public static final String HomePage_AllowDirectLogon_xpath="//div[text()='Allow Direct Logon After SSO Failure:']/following::div";
	public static final String HomePage_EnableUserDisplayName_xpath="//div[text()='Enable User Display Name:']/following::div";
	public static final String HomePage_RememberUserNameAtLogon_xpath="//div[text()='Remember User Name at Logon:']/following::div";
	public static final String HomePage_MessageFile_xpath="//div[text()='Message File:']/following::div";
	public static final String HomePage_ClientMessagePollingInterval_xpath="//div[text()='Client Message Polling Interval (minutes):']/following::div";
	public static final String HomePage_ServerMessageCache_xpath="//div[text()='Server Message Cache (minutes):']/following::div";
	public static final String HomePage_URItoUserProductivityKit_xpath="//div[text()='URI to User Productivity Kit:']/following::div";
	public static final String HomePage_PostLogoffURL_xpath="//div[text()='Post Logoff URL:']/following::div";
	public static final String HomePage_SmartViewURI_xpath="//div[text()='Smart View URI:']/following::div";
	public static final String HomePage_EnableInstallerMenuItemsInWorkspace_xpath="//div[text()='Enable Installer Menu Items in Workspace:']/following::div";
	public static final String HomePage_EnabledProducts_xpath="//div[text()='Enabled Products:']/following::div";
	public static final String HomePage_OKInServerSettings_xpath=".//button[@class='bi-button buttonPrimary']";


	//Validate_userOrGroupDirectoryBrowsing	

	public static final String  HomePage_UserDirectories_xpath=".//td[text()='User Directories']";
	public static final String  HomePage_UserDirectoriesArrow_xpath=".//td[text()='User Directories']/img";
	public static final String  HomePage_SameTimeLDAPArrow_xpath=".//td[text()='SameTimeLDAP']/img";
	public static final String  HomePage_Users_xpath=".//td[text()='Users']";
	public static final String  HomePage_UserProperty_xpath= ".//*[text()='User Property']";
	public static final String  HomePage_UserFilter_xpath=".//*[text()='User Filter']";
	public static final String  HomePage_InGroupsField_xpath=".//*[text()='In Group(s)']";
	public static final String  HomePage_PageSize_xpath=".//*[text()='Page Size']";
	public static final String  HomePage_SearchCriteriaMessage_xpath=".//td[text()='Enter search criteria to begin.']";
	public static final String  HomePage_UserFilterTextField_xpath="//*[text()='User Filter']/following::input";
	public static final String  HomePage_UserOrGroupNamesTable_xpath=".//table[@class='bi-tree-view-table']";	
	public static final String  HomePage_SearchButton_id="GridBtn";
	public static final String  HomePage_PropertiesIcon_xpath=".//img[@alt='Properties']";
	public static final String  HomePage_UserPropertiesWindow_xpath=".//div[text()='User Properties']";
	public static final String  HomePage_MemberOf_xpath=".//td[text()='Member Of']";
	public static final String  HomePage_SelectedGroupsList_xpath=".//table[@id='groupSelect']";
	public static final String  HomePage_OKButtonInUserProperties_ID="btnId_OK";
	public static final String  HomePage_OKButtonInUserPropertiesErrorWindow_className="primaryActive";
	public static final String  HomePage_Provision_xpath=".//img[@alt='Provision']";
	public static final String  HomePage_NativeDirectory_xpath=".//td[text()='Native Directory']/img";	
	public static final String  HomePage_Groups_xpath=".//td[text()='Groups']";
	public static final String  HomePage_GroupProperty_xpath=".//*[text()='Group Property']";
	public static final String  HomePage_GroupFilter_xpath= ".//*[text()='Group Filter']";
	public static final String  HomePage_GroupFilterTextField_xpath="//div[text()='Group Filter']/following::input";




	//FR validate New document/Page in File	

	public static final String  FRHomePage_File_id="bpm.mnbt_File";
	public static final String  FRHomePage_New_xpath=".//td[contains(text(),'ew')]";
	public static final String  FRHomePage_Document_xpath=".//td[contains(text(),'ocument...')]";
	public static final String  FRHomePage_CreateWorkSpaceButton_xpath=".//div[text()='Create a Workspace Page']";
	public static final String  FRHomePage_BottomButtonsPanel_xpath= ".//div[contains(@id,'navButtonPanel')]";
	public static final String  FRHomePage_Next_xpath=".//button[text()='Ne']";
	public static final String  FRHomePage_Templates_xpath=".//div[text()='Templates']";
	public static final String  FRHomePage_BackButton_xpath=".//button[text()='Bac']";
	public static final String  FRHomePage_CollectReportsIntoBookButton_xpath= ".//div[text()='Collect Reports into a Book']";
	public static final String  FRHomePage_SelectItemstobeAddedToBookHeader_xpath=".//div[text()='Select items to be added to book...']";
	public static final String  FRHomePage_BatchReportsForSchedulingButton_xpath= ".//div[text()='Batch Reports for Scheduling']";
	public static final String  FRHomePage_SelectItemstobeAddedToBatchHeader_xpath=".//div[text()='Select items to be added to batch...']";
	public static final String  FRHomePage_Cancel_xpath=".//button[text()='Cance']";


	//FR validate Open document/Page in File	

	public static final String  FRHomePage_Open_xpath=".//td[text()='pen']";
	public static final String  FRHomePage_LookIn_xpath="//div[text()='Look in:']/following::div";
	public static final String  FRHomePage_RootFolder_xpath=".//div[text()='Root']";
	public static final String  FRHomePage_FolderListTable_xpath= ".//table[@class='bi-tree-view-table']";
	public static final String  FRHomePage_PopUpContent_ID="DialogContentBodyContent";
	public static final String  FRHomePage_AllContent_Xpath="/html/body";
	public static final String  FRHomePage_CloseReportImage_xpath=".//*[contains(@id,'com.hyperion.bpm.web.common.TabButtonTextLabel')]/parent::div/img[contains(@class,'close')]";


	//FR validate Manage Favorites in Favorites				

	public static final String  FRHomePage_Favorites_xpath= ".//span[text()='ites']";
	public static final String  FRHomePage_ManageFavorites_xpath=".//td[text()='avorites...']";
	public static final String  FRHomePage_FavoritesManagerHeader_xpath= ".//div[text()='Favorites Manager']";
	public static final String  FRHomePage_FavoritesManagerDailogueTable_xpath=".//table[@class='bi-tree-view-table']";
	public static final String  FRHomePage_FavoritesDailogueBoxCancel_id="cds.favoritesdialog.cancel";



	// FR Validate_Navigation_AllAccessibleComponents		


	public static final String  FRHomePage_Explore_id= "wksp.mode.tlbt_ExploreMode";
	public static final String  FRHomePage_ExploreContent_xpath=".//table[@class='bi-tree-view-table']";
	public static final String  FRHomePage_RootFolderImage_xpath= ".//td[text()='Root']/img";
	public static final String  FRHomePage_OpenedFolderDetails_xpath=".//*[@id='bpmProcessBarArea']/div";
	public static final String  FRHomePage_FileMenuOptionsTable_id= ".//table[@class='bi-menu-table']/tbody";
	public static final String  FRHomePage_Tools_id="bpm.mnbt_Tools";



	// FR New/Delete Folders - All Accessible Components and Provision access - All Accessible Components

	public static final String  FRHomePage_NewFolderNameTextField_xpath= ".//div[text()='Please enter the name:']/following::input";
	public static final String  FRHomePage_SaveButton_xpath="//button[@class='bi-button buttonPrimary']";
	public static final String  FRHomePage_ErrorPopUp_id= ".//div[text()='Error']";
	public static final String  FRHomePage_ErrorMessage_xpath=".//div[@class='bi-label messageText']";
	public static final String  FRHomePage_OK_xpath= ".//button[text()='K']";
	public static final String  FRHomePage_CancelButton_xpath=".//span[text()='l']";
	public static final String  FRHomePage_Warning_xpath= ".//div[text()='Warning']";
	public static final String  FRHomePage_Edit_id="cds.mnbt_Edit";
	public static final String  FRHomePage_Delete_xpath= ".//td[text()='Delete']";
	public static final String  FRHomePage_YesConfirmation_xpath=".//span[text()='Y']";
	public static final String  FRHomePage_EditPermissions_xpath= ".//td[text()='dit Permissions...']";
	public static final String  FRHomePage_PermissionsTextOnWindow_xpath=".//div[text()='Permissions']";
	public static final String  FRHomePage_PermissionsWindowContent_xpath= ".//*[@id='tools.browser.aclPage.aclGrid']/div[2]/table/tbody";

	
	
	// HFM New/Delete Folders - All Accessible Components and Provision access - All Accessible Components
	
	
	public static final String  HFMHomePage_ConsolidationAdministration_xpath= ".//td[text()='onsolidation Administration']";
	public static final String  HFMHomePage_AppFrame_xpath=".//iframe[@src='http://10.34.66.188:19000/hfmadf/faces/hfm.jspx?themeSelection=Skyros&accessibilityMode=false']";
	public static final String  HFMHomePage_ApplicationsImage_xpath= ".//img[@alt='Applications']";
	public static final String  HFMHomePage_Application_xpath=".//span[text()='Applications']";
	public static final String  HFMHomePage_ApplicationsTable_xpath= ".//*[@id='pt1:rgnTb1:1:pt1:pc1:appstb::db']/table/tbody/tr/td[2]/div/table/tbody";
	public static final String  HFMHomePage_ConsolidationMenuOption_id="hfm.mnbt_Consolidation";
	public static final String  HFMHomePage_ConsolidationAdministrationTabClose_xpath= ".//div[text()='Consolidation Administration']/parent::div/img[@alt='Close']";
	
	
	//HFM Data Management - Accessing Process Details
	
	public static final String  HFMHomePage_DataManagement_xpath=".//td[text()='ment']";
	public static final String  HFMHomePage_DataManagementFrame_xpath= ".//iframe[@src='http://10.34.66.188:19000/aif/faces/mainPage']";
	public static final String  HFMHomePage_ProcessDetails_linktext="Process Details";
	public static final String  HFMHomePage_ProcessDetails_xpath= ".//span[text()='Process Details']";
	public static final String  HFMHomePage_DataManagementCloseTab_xpath=".//div[text()='Data Management']/parent::div/img[@alt='Close']";
	public static final String  HFMHomePage_PermissionsWindowContent_xpath= ".//*[@id='tools.browser.aclPage.aclGrid']/div[2]/table/tbody";


























/*

	public static final String HomePage_PopUpOk_ID="DSLogonDlgOkBtn";
	public static final String HomePage_Explore_CSS="div[id*='ExploreMode']";

	public static final String LoginPage_UserName_xpath="//table/tbody/tr[5]/td/input[contains(@id,'txtUser')]";

	//public static final String LoginPage_Explore_xpath="/html/body/div[7]/div/div[1]/div/div/div/div[3]/div[1]/div[4]";
	public static final String LoginPage_Explore_xpath="/html/body/div[8]/div/div[1]/div/div/div/div[3]/div[1]/div[4]";

	public static final String LoginPage_Explore_id="wksp.mode.tlbt_ExploreMode";

	public static final String HomePage_ReportPDFViewer_ID="reporting.reportViewer.tbPreviewPdf";*/


}

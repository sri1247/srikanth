package com.company.Monster.supportLibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Properties;
import javax.xml.bind.DatatypeConverter;
import com.company.Monster.objectRepository.*;
import com.company.Monster.pages.*;
import com.company.Monster.supportLibraries.*;


public class CommonLibrary {
	
	
    public static String getDateFull()
    {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 
		Calendar cal = Calendar.getInstance(); 
		String date = dateFormat.format(cal.getTime()); 
		String dateToReturn = date.toString();
		return dateToReturn;
    }
    public static String getDate()
    {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 
		Calendar cal = Calendar.getInstance(); 
		String date = dateFormat.format(cal.getTime()); 
		String dateToReturn = date.toString();
		dateToReturn = dateToReturn.replaceAll(" ", "_"); 
		dateToReturn = dateToReturn.replaceAll(":", ""); 
		dateToReturn = dateToReturn.replaceAll("/", ""); 
		return dateToReturn;
    }
    
	public static String convertSecondsToHMmSs(long seconds) {
	    long s = (seconds/1000) % 60;
	    long m = ((seconds/1000) / 60) % 60;
	    long h = ((seconds/1000) / (60 * 60)) % 24;
	    return String.format("%d:%02d:%02d", h,m,s);
	}

	public String getUserName() throws IOException
	{
		Properties prop = new Properties();
		String propFileName = "credentials.properties";

		FileInputStream inputStream = new FileInputStream(new File(propFileName));

		prop.load(inputStream);
		String strUserName = prop.getProperty("Username");
		return strUserName;

	}

	public String getPassword() throws IOException
	{
		Properties prop = new Properties();
		String propFileName = "credentials.properties";

		FileInputStream inputStream = new FileInputStream(new File(propFileName));

		prop.load(inputStream);
		String strPassword = prop.getProperty("Password");
		strPassword = new String(DatatypeConverter.parseBase64Binary(strPassword));
		return strPassword;

	}

}

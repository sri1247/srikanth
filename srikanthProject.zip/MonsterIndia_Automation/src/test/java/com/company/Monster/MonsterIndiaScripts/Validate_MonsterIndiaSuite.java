package com.company.Monster.MonsterIndiaScripts;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import com.company.Monster.factory.PageFactory;
import com.company.Monster.objectRepository.ObjRepo;
import com.company.Monster.pages.HomePage;
import com.company.Monster.pages.LoginPage;
import com.company.Monster.pages.MPowerSearchPage;
import com.company.Monster.supportLibraries.CommonLibrary;
import com.company.Monster.supportLibraries.ReadExcelInput;
import com.company.Monster.supportLibraries.ReportExcel;
import com.company.Monster.supportLibraries.ScreenShotLib;
import com.company.Monster.supportLibraries.SetUp;
import com.company.Monster.supportLibraries.testVariables;
import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;
//import com.company.monster.factory.PageFactory;

public class Validate_MonsterIndiaSuite {

	protected static RemoteWebDriver driver;
	static LoginPage loginPg;
	static HomePage homePg;
	static MPowerSearchPage mpowersearchPg;


	static CommonLibrary commonLibrary;

	public PageFactory getPageFactory(){
		return new PageFactory(driver);       

	}


	@BeforeClass(groups = { "Regression" })
	public void initialSetUp() throws IOException, MalformedURLException, Exception
	{

		SetUp.initSetUp();		

		commonLibrary= new CommonLibrary();

		String strUsername = commonLibrary.getUserName();

		String strPassword = commonLibrary.getPassword();

		try{

			loginPg = new LoginPage(driver, getPageFactory());// pageFact.loginPage();

			//loginPg.invokeBrowser(strURL,strBrowser);
			loginPg.invokeBrowser();

			Thread.sleep(5000);
			
			loginPg.closingChildWindow();
			
			System.out.println("closing the child window");

			//loginPg.switchToFrame("tagname", "frame");
			
			loginPg.RecruiterLogin();

			loginPg.enterUserName(strUsername);

			loginPg.enterPassword(strPassword);

			Thread.sleep(3000);

			homePg = loginPg.clickSignOn();
			
			homePg.waitForPgLoad();

			Thread.sleep(4000);

			homePg.existsOrNot("xpath",ObjRepo.HomePage_ConfirmationDEtailsPopupClose_xpath);										

			ReportExcel.addstep("Monster Job Portal-Login Validation","User is able to see the home page", "Login Successfull", "Pass");


		}
		catch(Exception e)
		{
			e.printStackTrace();

			//loginPg.closeAll();

			ReportExcel.addstep("Monster Job Portal-Login Validation","User is able to see the home page", "Login Failed", "Fail");
			
			ScreenShotLib.takeScreenshotAndSave("initialSetUp");

			throw new Exception("LoginFailed");
		}


	}

	@Test(priority=1,enabled=true)
		
		public void getProfiles() throws Exception

		{
		
			String anyFieldVal = ReadExcelInput.readFromCell("Any");
			
			String []arryanyfieldval=anyFieldVal.split("//;");
			
			String allFieldVal = ReadExcelInput.readFromCell("All");
			String excludingVal = ReadExcelInput.readFromCell("Excluding");
			String criteriaTypeVal = ReadExcelInput.readFromCell("CriteriaType");
			String excludeSynonymsCheck = ReadExcelInput.readFromCell("ExcludeSynonyms");
			String minimumYrsVal = ReadExcelInput.readFromCell("MinYrs");
			String maximumYrsVal = ReadExcelInput.readFromCell("MaxYrs");
			String industry = ReadExcelInput.readFromCell("Industry");
			String topSearchRole = ReadExcelInput.readFromCell("TopSearchRole");
			String subTopSearchRole = ReadExcelInput.readFromCell("SubTopSearchRole");
			String expRoleVal = ReadExcelInput.readFromCell("ChooseFromAllRoles");
			String subExpRoleVal = ReadExcelInput.readFromCell("SubChooseFromAllRoles");
			
			try {
				
				homePg.closingConfirmDetailsPopup();				

				mpowersearchPg=homePg.clickOnmPower();
				
				for(int i=0;i<arryanyfieldval.length;i++){
				
				mpowersearchPg.enterValueForAnyField(arryanyfieldval[0]);		
				
				}
								
				mpowersearchPg.enterValueForAllField(allFieldVal);
								
				mpowersearchPg.enterValueForExcludingField(excludingVal);
		
				mpowersearchPg.selectCreteriaType(criteriaTypeVal);
				
				mpowersearchPg.selectExcludeSynonyms(excludeSynonymsCheck);
				
				mpowersearchPg.enterExperience(minimumYrsVal, maximumYrsVal, industry, topSearchRole,subTopSearchRole, expRoleVal,subExpRoleVal);
				
				
			}

			catch(Exception e){

				System.out.println(e.getMessage());

				e.printStackTrace();
				
				ScreenShotLib.takeScreenshotAndSave("getProfiles");
			
				//ReportExcel.addstep("es in Consolidation Administration ","User is able to open the Required Applciation Successfully in.","The required scenario is not validated successfully. Beacause of the following issue: "+e.getMessage(),"Fail");				
				
			}

		}


	@AfterClass(groups = { "Regression" })

	public void afterExecution() throws IOException

	{
		
		//loginPg.closeAll();

		System.out.println("Closing the browser");
		
		//Email.send(toEmail, ccEmail," EPM HFM Workspace - Status Report","Please find the attached to check the status of HFM Tests Run",testVariables.fileOutput);
	}
}
package com.company.Monster.pages;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
//import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.poi.ddf.EscherColorRef.SysIndexProcedure;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.company.Monster.factory.PageFactory;
import com.company.Monster.objectRepository.*;
import com.company.Monster.supportLibraries.*;


public class MPowerSearchPage extends PageBase{
	
	
	public MPowerSearchPage(RemoteWebDriver driver, PageFactory pageFactory){
		super(driver, pageFactory);
		
	}
	
	public MPowerSearchPage enterValueForAnyField(String value) throws Exception

	{
		
		invokeWebDriverWait(120, "visibilityofelementlocated", "id","anw");
		
		clickOnEle("id", "anw");
		
		clearText("id", "anw");
		
		setValue("id", "anw", value);

		System.out.println("Entered the value for any field");

		return this;

	}
	
	
	public MPowerSearchPage enterValueForAllField(String value) throws Exception

	{
		
		//invokeWebDriverWait(120, "visibilityofelementlocated", "id","alw");
		
		clickOnEle("id", "alw");
		
		clearText("id", "alw");
		
		setValue("id", "alw", value);

		System.out.println("Entered the value for all field");

		return this;

	}
	
	public MPowerSearchPage enterValueForExcludingField(String value) throws Exception

	{
		
		//invokeWebDriverWait(120, "visibilityofelementlocated", "id","now");
		
		clickOnEle("id", "now");
		
		clearText("id", "now");
		
		setValue("id", "now", value);

		System.out.println("Entered the value for excluding field");

		return this;

	}
	
	
	public MPowerSearchPage selectCreteriaType(String value) throws Exception

	{
		
		//invokeWebDriverWait(120, "visibilityofelementlocated", "id","search_within_power");
		
		clickOnEle("id", "search_within_power");
				
		clickOnEle("linktext",value);

		System.out.println("select the type if it's entire resume,keyskills etc..");

		return this;

	}
	
	
	public MPowerSearchPage selectExcludeSynonyms(String value) throws Exception

	{
		
		if(value.equalsIgnoreCase("yes")){
		
		clickOnEle("xpath", ".//div[text()='Exclude synonyms']/parent::div/div[@class='chkbox left check_select']");
				
		}
		
		else{
			
		}	

		System.out.println("checking/unchecking exclude synonyms");

		return this;

	}
	
	public MPowerSearchPage enterExperience(String minYrs,String maxYrs,String industry,String topSearchRole,String subTopSearchRole,String expRole,String subExpRole) throws Exception

	{
		
		clickOnEle("id", "idMne");
		
		setValue("id", "idMne", minYrs);
		
		clickOnEle("id", "idMxe");
		
		setValue("id", "idMxe", maxYrs);
		
		clickOnEle("id", "industry_container");
		
		setValue("id", "selInd_typeahead",industry);
		
		Thread.sleep(2000);
		
		clickOnEle("xpath", ".//div[@title='"+industry+"']");
		
		clickOnEle("id", "industry_container");
		
		/*if(existsOrNot("id", "topRole_container")){
		
		clickOnEle("id", "topRole_container");
		
		setValue("id", "selRol_typeahead",topSearchRole);
		
		Thread.sleep(2000);
		
		clickOnEle("xpath", ".//div[@title='"+topSearchRole+"']");
		
		clickOnEle("xpath", ".//div[@title='"+subTopSearchRole+"']");
		
		clickOnEle("id", "topRole_container");
		
		}
		*/
		clickOnEle("id", "otherRole_container");
		
		setValue("id", "selRol2_typeahead",expRole);
		
		Thread.sleep(2000);
		
		clickOnEle("xpath", ".//b[text()='"+expRole+"']");
		
		Thread.sleep(3000);
		
		clickOnEle("xpath", ".//div[text()='"+subExpRole+"']");
		
		clickOnEle("id", "otherRole_container");

		return this;
	}
	
	

	}



